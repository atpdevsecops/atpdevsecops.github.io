---
layout: default
title: "Über mich"
---

🌐 [English](index.md) | [Türkçe](index-tr.md) | [Deutsch](index-de.md)

# 👤 Über mich – Ahmet

- 🇩🇪 Seit 7 Jahren in Deutschland wohnhaft  
- 🎓 Mathematik-Background  
- 🛡 1 Jahr intensives Cybersecurity-Training  
- 💻 CompTIA Security+ zertifiziert  
- 🤖 AI-gestütztes Lernen mit ChatGPT+, Gemini, Monica  
- 📦 Projekte mit Docker, GitHub Actions, Trivy  
- 🐦 Früher Twitter-Accounts mit über 1M Follower  
- 🌐 Eigene Webseite seit 5 Jahren aktiv  
