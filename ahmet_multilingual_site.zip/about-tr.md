---
layout: default
title: "Hakkımda"
---

🌐 [English](index.md) | [Türkçe](index-tr.md) | [Deutsch](index-de.md)

# 👤 Hakkımda – Ahmet

- 🇩🇪 7 yıldır Almanya’da yaşıyorum  
- 🎓 Matematik mezunuyum  
- 🛡 1 yıllık hızlandırılmış siber güvenlik eğitimi aldım  
- 💻 CompTIA Security+ sertifikasına sahibim  
- 🤖 Yapay zekâ destekli öğreniyorum: ChatGPT+, Gemini Pro, Monica  
- 📦 Docker, GitHub Actions, Trivy ile projeler geliştiriyorum  
- 🐦 Eski 1M takipçili Twitter hesap yöneticisiyim  
- 🌐 5 yıldır aktif kişisel web sitem var  
