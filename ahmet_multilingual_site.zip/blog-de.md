---
layout: default
title: "Blog"
---

🌐 [English](index.md) | [Türkçe](index-tr.md) | [Deutsch](index-de.md)

# 📓 Blog

Erfahrungen aus meinem KI-gestützten DevSecOps-Lernweg.

## 🚀 Erstes Projekt: Secure Note App

- Flask + Docker + Trivy  
- Code größtenteils mit ChatGPT erstellt  
- Mein erstes funktionierendes CI/CD-Projekt

## 🧠 Was mir KI gebracht hat

- Technisches Englisch besser verstanden  
- Schnellere Analyse von Code  
- Fehlerfreier entwickelt  
