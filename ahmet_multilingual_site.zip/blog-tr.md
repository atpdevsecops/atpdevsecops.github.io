---
layout: default
title: "Blog"
---

🌐 [English](index.md) | [Türkçe](index-tr.md) | [Deutsch](index-de.md)

# 📓 Blog

Yapay zekâ destekli DevSecOps öğrenme sürecimdeki deneyimlerimi burada paylaşıyorum.

## 🚀 İlk Proje: Güvenli Not Defteri

- Flask + Docker + Trivy
- Kodların çoğu ChatGPT ile yazıldı
- CI/CD sürecini ilk kez uyguladım

## 🧠 Yapay Zekâ Bana Ne Kazandırdı?

- Teknik İngilizceyi anlamam kolaylaştı  
- Kodları hızlı analiz etmeyi öğrendim  
- Daha az hata ile proje geliştirdim  
